	<div class="navboxbg">
	<p class="tabtitle">STEPS</p>
		<ul class="nav nav-tabs tablistdatao" id="myTab" role="tablist">
			<li class="tabmargin" role="presentation" data-bs-toggle="tooltip" data-bs-placement="top">
				<a class="colortab active d-flex" href="#step1" id="step1-tab" data-bs-toggle="tab" role="tab" aria-controls="step1" aria-selected="true">
					<i class="lefttabicon fa fa-pencil-square-o"></i> Add / Edit 
					<i class="fa fa-caret-right righttbicon"></i>
				</a>
			</li>
			
			<li class="tabmargin" role="presentation" data-bs-toggle="tooltip" data-bs-placement="top">
				<a class="colortab d-flex" href="#step2" id="step2-tab" data-bs-toggle="tab" role="tab" aria-controls="step2" aria-selected="true">
					<i class="lefttabicon fa fa-id-card-o"></i> Contact Details
					<i class="fa fa-caret-right righttbicon"></i>
				</a>
			</li>
			
			
			<li class="tabmargin" role="presentation" data-bs-toggle="tooltip" data-bs-placement="top">
				<a class="colortab d-flex" href="#step3" id="step3-tab" data-bs-toggle="tab" role="tab" aria-controls="step3" aria-selected="true">
					<i class="lefttabicon fa fa-clock-o"></i> Arrival Details 
					<i class="fa fa-caret-right righttbicon"></i>
				</a>
			</li>
			
			<li class="tabmargin" role="presentation" data-bs-toggle="tooltip" data-bs-placement="top">
				<a class="colortab d-flex" href="#step4" id="step4-tab" data-bs-toggle="tab" role="tab" aria-controls="step4" aria-selected="true">
					<i class="lefttabicon fa fa-home"></i> Accommodation 
					<i class="fa fa-caret-right righttbicon"></i>
				</a>
			</li>
			
			
			<li class="tabmargin" role="presentation" data-bs-toggle="tooltip" data-bs-placement="top">
				<a class="colortab d-flex" href="#step5" id="step5-tab" data-bs-toggle="tab" role="tab" aria-controls="step5" aria-selected="true">
					<i class="lefttabicon fa fa-car"></i> Transport Details 
					<i class="fa fa-caret-right righttbicon"></i>
				</a>
			</li>
			
			<li class="tabmargin" role="presentation" data-bs-toggle="tooltip" data-bs-placement="top">
				<a class="colortab d-flex" href="#step6" id="step6-tab" data-bs-toggle="tab" role="tab" aria-controls="step6" aria-selected="true">
					<i class="lefttabicon fa fa-sticky-note-o"></i> Waaz Details 
					<i class="fa fa-caret-right righttbicon"></i>
				</a>
			</li>
			
			
			<li class="tabmargin" role="presentation" data-bs-toggle="tooltip" data-bs-placement="top">
				<a class="colortab d-flex" href="#step7" id="step7-tab" data-bs-toggle="tab" role="tab" aria-controls="step7" aria-selected="true">
					<i class="lefttabicon fa fa-envelope"></i> Invite Mehman 
					<i class="fa fa-caret-right righttbicon"></i>
				</a>
			</li>
			
			<li class="tabmargin" role="presentation" data-bs-toggle="tooltip" data-bs-placement="top">
				<a class="colortab d-flex" href="#step8" id="step8-tab" data-bs-toggle="tab" role="tab" aria-controls="step8" aria-selected="true">
					<i class="lefttabicon fa fa-ship"></i> Mawaid 
					<i class="fa fa-caret-right righttbicon"></i>
				</a>
			</li>
			
			<li class="tabmargin" role="presentation" data-bs-toggle="tooltip" data-bs-placement="top">
				<a class="colortab d-flex" href="#step9" id="step9-tab" data-bs-toggle="tab" role="tab" aria-controls="step9" aria-selected="true">
					<i class="lefttabicon fa fa-paper-plane-o"></i> Parking
					<i class="fa fa-caret-right righttbicon"></i>
				</a>
			</li>
			
			<li class="tabmargin" role="presentation" data-bs-toggle="tooltip" data-bs-placement="top">
				<a class="colortab d-flex" href="#step10" id="step10-tab" data-bs-toggle="tab" role="tab" aria-controls="step10" aria-selected="true">
					<i class="lefttabicon fa fa-check-square-o"></i> Check Status 
					<i class="fa fa-caret-right righttbicon"></i>
				</a>
			</li>
			
			
			
		</ul>
		
		</div>
		