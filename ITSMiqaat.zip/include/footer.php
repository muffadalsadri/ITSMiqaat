


  <script src="js/jquery.min.js"></script>
  <script src="js/popper.min.js"></script>
  
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
  

<script>

$(document).ready(function () {


	//Advance Tabs
	$(".next").click(function () {
		const nextTabLinkEl = $(".nav-tabs .active")
			.closest("li")
			.next("li")
			.find("a")[0];
		const nextTab = new bootstrap.Tab(nextTabLinkEl);
		nextTab.show();
	});

	$(".previous").click(function () {
		const prevTabLinkEl = $(".nav-tabs .active")
			.closest("li")
			.prev("li")
			.find("a")[0];
		const prevTab = new bootstrap.Tab(prevTabLinkEl);
		prevTab.show();
	});
});

</script>

<script>
var skills = $('.skill-item');
var skillsSum = skills.length;
var radius = 42;
var circleLength=2*Math.PI*radius;
for(let i = 0;i<skillsSum;i++){
  var skill=skills.eq(i);
  var attr = skill.attr('data-value');
  if(attr>100){
    attr=100;
  }
  if(attr<0){
    attr=1;
  }
  var value = circleLength- attr*circleLength/100;
  skill.find('.skill-path').css('stroke-dashoffset',value);
   
}

console.log($.fn.autocomplete);
</script>





</body>
</html>




 
