<!DOCTYPE html>
<html lang="en">
<head>
  <title>ITS Miqaat</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/index.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

  
  
</head>
<body>

<section class="topbarsection">
	<div class="container">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-8">
			  <div class="m-0 topbardev">
			    <span class="topbardevfirstname"> Download ITS App on </span>
				 <a href=""><img src="img/playstore.png"></a>
				 <a href=""><img src="img/apple.png"></a>
				 <span class="topbardevspan"> | </span>
				 <a class="topbarbutton" href="">Monday, 7 Rabi AI Awwal 1444 AH</a>
			  </div>
			</div>
		</div>
	</div>
</section>

<section class="navbarsectopn">

<nav class="navbar navbar-expand-md p-0 container">
  <a class="navbar-brand navlogo" href="index.php"><img src="img/logo.png"></a>
  <button class="navbar-toggler mr-2 text-white" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
      <span class="fa fa-bars"></span>
    </button>
    
  <div class="collapse navbar-collapse menudatalist" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Members List</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Warning</a>
      </li>    
	  <li class="nav-item">
        <a class="nav-link" href="#">History</a>
      </li>    
    </ul>
  </div>
  
  
  <ul class="m-0 navprofilebox">
      <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle navprofile" href="#" role="button" id="navbardrop" data-bs-toggle="dropdown">
      <img src="img/profile.png"> <span> Mulla Quraish Bhai</span>
      </a>
      <div class="dropdown-menu p-0">
        <a class="dropdown-item demooklik" href="#">User ID : 0123456789</a>
        <a class="dropdown-item dropdow-buttonlisk" href="#">Logout</a>
      </div>
    </li>
  </ul>
  
</nav>
</section>
