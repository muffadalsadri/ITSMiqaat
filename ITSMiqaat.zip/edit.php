	    <?php include('include/header.php'); ?>


<section class="mt-5">

<div class="container">
<div class="row">
<div class="col-md-12">
<h5 class="title-icons"><img src="img/leftarrow.png"> Test 10 days 1444H., Testing</h5>
</div>
</div>
</div>

<div class="container">
	<div class="wizard mt-2">
	    
	    <?php include('include/tabbar.php'); ?>

		
		<div class="tab-content" id="myTabContent">
		    
<!---------- 1st Start ------->

<div class="tab-pane fade show active" role="tabpanel" id="step1" aria-labelledby="step1-tab">
<section class="mt-5">  
<div class="container">
<div class="row">

<div class="col-md-6 mt-3">
<div class="date_box"> 
<h3>Important Dates</h3>

<ul>
<li>Maharram uI Haraam 144H <span>August 2022</span> </li>
<li>Registration End Date <span>30 September 2022, 06:00 PM</span> </li>
<li>Check Waaz Allocation on <span>Allocation is Live</span> </li>
</ul>


<div class="row align-items-center">
<div class="col-md-6">
<p>Time Remaining for Registration </p>    
</div>
<div class="col-md-6 col-pd">
<ul class="img_li">
<li><img src="img/ellipse-19@1x.png"><span>3<br>Days</span></li>
<li><img src="img/ellipse-17@1x.png"><span>4<br>Hrs</span></li>
<li><img src="img/ellipse-15@1x.png"><span>2<br>Mins</span></li>
<li><img src="img/ellipse-14@1x.png"><span>10<br>Sec</span></li>
</ul>
</div>
</div>


</div>
</div>

<div class="col-md-6 mt-3">
<div class="add_member_bx">

<h3 class="member_add">Add Member</h3> 
<div class="row">

<div class="col-md-6 form_col">
<form class="form_margin">
<div class="input-wrapper">
<input type="text" id="id" value="1254666" required>
<label class="firstlabel" for="id">ITS ID</label>
</div>

<div class="input-wrapper mt-3">
<input type="text" id="pass" value="1254666" required>
<label  class="firstlabel" for="pass">Password</label>
</div>

<div class="input-wrapper mt-3">
<input type="submit" class="add_input" id="addgroup" value="Add To Group" required>
</div>
</form>
</div>



<div class="col-md-6">
<div class="margintext">
<p>To add members to your group, kindly enter ITS ID & Password and click on <span>"Add To Group"</span> Button.</p>
<span class="orspan">OR</span>
<p class="Register_Member"><a href="#">Register Member(s) from your Member(s) List.</a></p>
</div>
</div>
</div>
</div>
</div>


<div class="col-md-12 tbl_col">
<div class="table_add_member_bx">
<div class="list_group">
<h4>List of Group Member(s)<span class="span_btn5">5</span></h4>
</div>

<div class="table-responsive">
<table class="table table_design">
<thead>
<tr>
<th>Sr.</th>
<th>ITS ID</th>
<th>Full Name</th>
<th>Registration Status</th>
<th>Raza Status</th>
<th>WaraQat-ul Tarkhis</th>
<th><img src="img/icon-material-error-outline-1@1x.png" width="14px"> </th>
</tr>
</thead>
<tbody class="t-body">
    
<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td>Arrival/Departure details NOT entered</td>
<td>Pending</td>
<td>NOT Renewed</td>
<td>0</td>
<td>Cancel Registration</td>
</tr>

<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img"> Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td>Arrival/Departure details NOT entered</td>
<td>Pending</td>
<td>NOT Renewed</td>
<td>0</td>
<td>Cancel Registration</td>
</tr>

</tbody>
</table>
</div>

</div>
</div>


</div>
</div>
</section>
</div>

<!---------- 1st End ------->

<!---------- 2nd End ------->

<div class="tab-pane fade" role="tabpanel" id="step2" aria-labelledby="step2-tab">
<section class="mt-5">
<div class="container">    
<div class="row">
<div class="col-md-12">
<h3 class="miqaat_list">Update Contact Details</h3>
</div>

<div class="col-md-12">
<div class="tab-2box">
<div class="update_contact_box">
<h4 class="boxheadding">List of Registered group Member(s)<span class="span_btn5">3</span></h4>

<div class="textimglist">
<span>1. </span>
<img src="img/image-26-12@1x.png" class="shaikh_img">
<div class="textimglistnxt">
<p>30462903</p><p>Mulla Quraish bhai Shaikh Abizer bhai Tyebji</p>
</div>
</div>
<div class="departure_detail">
<div class="row">
<div class="col-md-4">
<div class="row">
<div class="col-md-8"><p class="m-0">Registration Status</p><p class="arrival_font_red"> Arrival / Departure details NOT entered</p></div>
<div class="col-md-4"><p class="install">ITS App Installed</p></div>
</div>    
</div>   
<div class="col-md-8">
  <form action="" class="form_input">
      <div class="row">
    <div class="form-group form_input_bx col-md-4">
        <span><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
      <input type="email" class="form-control" id="email" placeholder="Email" name="email">
    </div>
    
        <div class="form-group form_input_bx col-md-4">
                <span><i class="fa fa-phone" aria-hidden="true"></i></span>
      <input type="number" class="form-control" id="number" placeholder="Phone" name="phone">
    </div>
    
       <div class="form-group form_input_bx col-md-4">
               <span><i class="fa fa-comment-o" aria-hidden="true"></i></span>
      <input type="text" class="form-control" id="whatsapp" placeholder="Whatsapp" name="whatsapp">
    </div>
  </div>    
  </form>  
</div>
</div>
</div>


<div class="textimglist">
<span>1. </span>
<img src="img/image-26-12@1x.png" class="shaikh_img">
<div class="textimglistnxt">
<p>30462903</p><p>Mulla Quraish bhai Shaikh Abizer bhai Tyebji</p>
</div>
</div>
<div class="departure_detail">
<div class="row">
<div class="col-md-4">
<div class="row">
<div class="col-md-8"><p class="m-0">Registration Status</p><p class="arrival_font_red"> Arrival / Departure details NOT entered</p></div>
<div class="col-md-4"><p class="install">ITS App Installed</p></div>
</div>    
</div>   
<div class="col-md-8">
  <form action="" class="form_input">
      <div class="row">
    <div class="form-group form_input_bx col-md-4">
        <span><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
      <input type="email" class="form-control" id="email" placeholder="Email" name="email">
    </div>
    
        <div class="form-group form_input_bx col-md-4">
                <span><i class="fa fa-phone" aria-hidden="true"></i></span>
      <input type="number" class="form-control" id="number" placeholder="Phone" name="phone">
    </div>
    
       <div class="form-group form_input_bx col-md-4">
               <span><i class="fa fa-comment-o" aria-hidden="true"></i></span>
      <input type="text" class="form-control" id="whatsapp" placeholder="Whatsapp" name="whatsapp">
    </div>
  </div>    
  </form>  
</div>
</div>
</div>

</div>
</div>

</div>        
</div>    
</div>
</section>   
</div>

<!---------- 2nd End ------->

<!---------- 3rd Start ------->

<div class="tab-pane fade" role="tabpanel" id="step3" aria-labelledby="step3-tab">
<section class="mt-5">
<div class="container">    
<div class="row">
<div class="col-md-12">
<h3 class="miqaat_list">Update Contact Details</h3>
</div>

<div class="col-md-12">
<div class="tab-2box">
<div class="update_contact_box">
<h4 class="boxheadding">List of Registered group Member(s)<span class="span_btn5">3</span></h4>

<div class="row">
<div class="col-md-6">
<h4 class="text-center titlebgtext">Arrival in TESTING</h4>

<div class="row colrdatafild">
<div class="col-lg-4">
<p class="">Mode</p>                       
</div>
<div class="col-lg-8">  
<select class="form-control">
<option>1</option>    
<option>2</option>
<option>3</option>    
</select>
</div>
</div>

<div class="row colrdatafild">
<div class="col-lg-4">
<p class="">Flight</p>                       
</div>
<div class="col-lg-8">
<input type="text" class="form-control" placeholder="" name="text">  
</div>
</div>

<div class="row colrdatafild">
<div class="col-lg-4">
<p class="">Airline</p>                       
</div>
<div class="col-lg-8">
<input type="text" class="form-control" placeholder="" name="text">  
</div>
</div>


<div class="row colrdatafild">
<div class="col-lg-4">
<p class="">Flight Code</p>                       
</div>
<div class="col-lg-8">
<input type="text" class="form-control" placeholder="" name="text">  
</div>
</div>

<div class="row colrdatafild">
<div class="col-lg-4">
<p class="">Airport</p>                       
</div>
<div class="col-lg-8">
<input type="text" class="form-control" placeholder="" name="text">  
</div>
</div>

<div class="row colrdatafild">
<div class="col-lg-4">
<p class="">Ticket No. / PNR No.</p>                       
</div>
<div class="col-lg-8">
<input type="text" class="form-control" placeholder="" name="text">  
</div>
</div>

<div class="row colrdatafild">
<div class="col-lg-4">
<p class="">Arrival Date </p>                       
</div>
<div class="col-lg-4">
<input type="date" class="form-control" placeholder="" name="text">  
</div>
<div class="col-lg-4">
<input type="time" class="form-control" placeholder="" name="text">  
</div>
</div>





</div>

<div class="col-md-6">
<h4 class="text-center titlebgtext">Departure Froom TESTING</h4>

<div class="row colrdatafild">
<div class="col-lg-4">
<p class="">Mode</p>                       
</div>
<div class="col-lg-8">  
<select class="form-control">
<option>1</option>    
<option>2</option>
<option>3</option>    
</select>
</div>
</div>

</div>

</div>    



</div>
</div>

</div>      

<div class="col-md-12 tbl_col">
<div class="table_add_member_bx">
<div class="list_group">
<h4>List of Group Member(s)<span class="span_btn5">5</span></h4>
</div>

<div class="table-responsive">
<table class="table table_design">
<thead>
<tr>
<th>Sr.</th>
<th>ITS ID</th>
<th>Full Name</th>
<th>Registration Status</th>
<th>Arrival Details</th>
<th>Departure Details</th>
</tr>
</thead>
<tbody class="t-body">
    
<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td class="text-danger">Arrival/Departure details NOT entered</td>
<td class="text-danger">Pending</td>
<td class="text-danger">NOT Renewed</td>
</tr>

<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img"> Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td class="text-danger">Arrival/Departure details NOT entered</td>
<td class="text-danger">Pending</td>
<td class="text-danger">NOT Renewed</td>
</tr>

</tbody>
</table>
</div>

</div>
</div>

</div>    
</div>
</section>   
</div>

<!----3rd END----->


<!------4th start ------>

<div class="tab-pane fade" role="tabpanel" id="step4" aria-labelledby="step4-tab">
    <section class="mt-5">
<div class="container">    
<div class="row">
<div class="col-md-12">
<h3 class="miqaat_list">Accommodation</h3>
</div>

<div class="col-md-12">
<div class="tab-2box">
<div class="update_contact_box">
<h4 class="boxheadding">Apply Changes to All</h4>

<div class="row">
<div class="col-md-6">
<div class="row colrdatafild">
<div class="col-lg-4">
<p class="">Mode</p>                       
</div>
<div class="col-lg-8">  
<select class="form-control">
<option>1</option>    
<option>2</option>
<option>3</option>    
</select>
</div>
</div>
</div>
</div>    


</div>
</div>

</div>      

<div class="col-md-12 tbl_col">
<div class="table_add_member_bx">
<div class="list_group">
<h4>List of Group Member(s)<span class="span_btn5">5</span></h4>
</div>

<div class="table-responsive">
<table class="table table_design">
<thead>
<tr>
<th>Sr.</th>
<th>ITS ID</th>
<th>Full Name</th>
<th>Registration Status</th>
<th>Accommodation Type</th>
<th>Zone</th>
<th>Accommodation Info</th>
</tr>
</thead>
<tbody class="t-body">
    
<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td class="text-danger">Arrival/Departure details NOT entered</td>
<td class="text-danger">NOT Selected</td>
<td class="text-danger">-</td>
<td class="text-danger">-</td>
</tr>

<tr>
<td>2.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td class="text-danger">Arrival/Departure details NOT entered</td>
<td class="text-danger">NOT Selected</td>
<td class="text-danger">-</td>
<td class="text-danger">-</td>
</tr>

</tbody>
</table>
</div>

</div>
</div>

</div>    
</div>
</section> 
</div>    

<!--------4th End ------->

<!--------5th Start ------>

<div class="tab-pane fade" role="tabpanel" id="step5" aria-labelledby="step5-tab">
<section class="mt-5">
<div class="container">    
<div class="row">   

<div class="col-md-12 tbl_col">
<div class="table_add_member_bx">
<div class="list_group">
<h4>List of Group Member(s)<span class="span_btn5">5</span></h4>
</div>

<div class="table-responsive">
<table class="table table_design">
<thead>
<tr>
<th>Sr.</th>
<th>ITS ID</th>
<th>Full Name</th>
<th>Registration Status</th>
<th>How Will you travel from your accommodation to waaz during Ashara?</th>
</tr>
</thead>
<tbody class="t-body">
    
<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td class="text-danger">Arrival/Departure details NOT entered</td>
<td class="text-danger">
    <div class="colrdatafild">
    <select class="form-control">
    <option>1</option>    
    <option>2</option>
    <option>3</option>    
    </select>
    </div>
</td>
</tr>

<tr>
<td>2.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td class="text-danger">Arrival/Departure details NOT entered</td>
<td>
<div class="colrdatafild">
<select class="form-control">
<option>1</option>    
<option>2</option>
<option>3</option>    
</select>
</div>
</td>
</tr>

</tbody>
</table>
</div>

</div>
</div>

</div>    
</div>
</section>   
</div>
<!--------5th End -------->

<!--------6th End -------->
<div class="tab-pane fade" role="tabpanel" id="step6" aria-labelledby="step6-tab">
<section class="mt-5">
<div class="container">    
<div class="row">   
<div class="col-md-12">
<h3 class="miqaat_list">Waaz Details</h3>
</div>

<div class="col-md-12 tbl_col">
<div class="table_add_member_bx">
<div class="list_group">
<h4>List of Group Member(s)<span class="span_btn5">5</span></h4>
</div>

<div class="table-responsive">
<table class="table table_design">
<thead>
<tr>
<th>Sr.</th>
<th>ITS ID</th>
<th>Full Name</th>
<th>Registration Status</th>
<th>Waaz Details </th>
</tr>
</thead>
<tbody class="t-body">
    
<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td class="text-danger">Arrival/Departure details NOT entered</td>
<td class="text-danger">
    <div class="colrdatafild">
    <select class="form-control">
    <option>1</option>    
    <option>2</option>
    <option>3</option>    
    </select>
    </div>
</td>
</tr>

<tr>
<td>2.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td class="text-danger">Arrival/Departure details NOT entered</td>
<td>
<div class="colrdatafild">
<select class="form-control">
<option>1</option>    
<option>2</option>
<option>3</option>    
</select>
</div>
</td>
</tr>

</tbody>
</table>
</div>

</div>
</div>

</div>    
</div>
</section>  
</div>
<!--------6th End -------->


<div class="tab-pane fade" role="tabpanel" id="step10" aria-labelledby="step10-tab">
<section class="mt-5">

<div class="container">
<form action="" class="form_page">
<div class="row">	
<div class="col-lg-6">
<div class="box_border mb-4">

<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="jamaat" class="mb-2">Jamaat</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2" id="jamaat" placeholder="HOUSTON" name="text">  
</div>
</div>
</div>   



<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Jamiaat" class="mb-2">Jamiaat</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2" id="Jamiaat" placeholder="USA" name="text">  
</div>
</div>
</div>   


<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Idara" class="mb-2">Idara</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2" id="Idara" placeholder="-" name="text">  
</div>
</div>
</div>   



<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Gender" class="mb-2">Gender & Age</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2"  id="Gender" placeholder="Male 28 Yrs." name="text">  
</div>
</div>
</div>   


</div>
</div>


<div class="col-lg-6">
<div class="box_border_01">

<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Email" class="mb-2 mr-sm-2">Email</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2 mr-sm-2" id="Email" placeholder="qtyebji@gmail.com" name="text">  
</div>
</div>
</div>   



<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Mobile" class="mb-2 mr-sm-2">Mobile No,</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="number" class="form-control mb-2 mr-sm-2" id="Mobile" placeholder="+17135022300" name="text">  
</div>
</div>
</div>   



<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="WhatsApp" class="mb-2 mr-sm-2">WhatsApp No.</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="number" class="form-control mb-2 mr-sm-2" id="WhatsApp" placeholder="+17135022300" name="text">  
</div>
</div>
</div>   


</div>
</div>

</div>
</form>
<form action="" class="form_page">
<div class="row mt-3">	
<div class="col-lg-6 mt-3">
<div class="box_border">

<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Registered" class="mb-2">Registered On</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2" id="Registered" placeholder="26-Sep-2022 07:06 AM" name="text">  
</div>
</div>
</div>   



<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Registered_By" class="mb-2">Registered By</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2" id="Registered_By" placeholder="30462903" name="text">  
</div>
</div>
</div>   


<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Reg" class="mb-2">Reg Status</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2" id="Reg" placeholder="Amival/Departure detalls NOT entered" name="text">  
</div>
</div>
</div>   



<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Wordgat" class="mb-2">Wordgat ul Tarnis</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2" id="Wordgat" placeholder="Not renewed (Misoq Done)" name="text">  
</div>
</div>
</div>   


</div>
</div>


<div class="col-lg-6 mt-3">
<div class="box_border_01">

<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Raza" class="mb-2 mr-sm-2">Raza</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2 mr-sm-2" id="Raza" placeholder="Pending" name="text">  
</div>
</div>
</div>   



<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Accommodation" class="mb-2 mr-sm-2">Accommodation</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2 mr-sm-2" id="Accommodation" placeholder="You have not selected any option in Accommodation details" name="text">  
</div>
</div>
</div>   



<div class="row">
<div class="col-lg-4" id="coloum_jamaat">
<div class="jammat_01">					 
<label for="Arrival" class="mb-2 mr-sm-2">Arrival Scanning</label>                       
</div>
</div>
<div class="col-lg-8" id="coloum_jamaat">
<div class="jammat_02">
<input type="text" class="form-control mb-2 mr-sm-2" id="Arrival" placeholder="Arrival scanning not done" name="text">  
</div>
</div>
</div>   


</div>
</div>

</div>
</form>
</div>
</section>
<section class="mt-3">
<div class="container">    
<div class="row">   

<div class="col-md-12 tbl_col">
<div class="table_add_member_bx">
<div class="list_group">
<h4>List of Group Member(s)<span class="span_btn5">5</span></h4>
</div>

<div class="table-responsive">
<table class="table table_design">
<thead>
<tr>
<th>Sr.</th>
<th>ITS ID</th>
<th>Full Name</th>
<th>Registration Status</th>
<th>Raza Status</th>
<th>Accomm Status</th>
<th>!</th>
<th>Data Status</th>
<th>Photo Status</th>
<th>Vaccinatin Status</th>
</tr>
</thead>
<tbody class="t-body">

<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td class="text-danger">Arrival/Departure details NOT entered</td>
<td>Pending</td>
<td class="text-danger">Not Renewed</td>
<td>0</td>
<td>VIRIFIED</td>
<td>VIRIFIED</td>
<td>DOUBLE/FULLY VACCINATED</td>
</tr>

<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td class="text-danger">Arrival/Departure details NOT entered</td>
<td>Pending</td>
<td class="text-danger">Not Renewed</td>
<td>0</td>
<td>VIRIFIED</td>
<td>VIRIFIED</td>
<td>DOUBLE/FULLY VACCINATED</td>
</tr>


</tbody>
</table>
</div>

</div>
</div>

</div>    
</div>
</section>   
</div>

</div>
		
</div>
</div>

</section>

<div class="dbetween">
<a class="btn btn-secondary previous"> Save</a>
<a class="btn btn-info next nextbutton">Next</a>
</div>


<?php include('include/footer.php'); ?>
