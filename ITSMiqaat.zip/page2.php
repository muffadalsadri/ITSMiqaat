<!DOCTYPE html>
<html lang="en">
<head>
  <title>Miqaat</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<section class="">  
<div class="container">
<div class="row">

<div class="col-md-6">
<div class="date_box"> 
<h3>Important Dates</h3>

<ul>
<li>Maharram uI Haraam 144H <span>August 2022</span> </li>
<li>Registration End Date <span>30 September 2022, 06:00 PM</span> </li>
<li>Check Waaz Allocation on <span>Allocation is Live</span> </li>
</ul>


<div class="row align-items-center">
<div class="col-md-6">
<p>Time Remaining for Registration </p>    
</div>
<div class="col-md-6 col-pd">
<ul class="img_li">
<li><img src="img/ellipse-19@1x.png"><span>3<br>Days</span></li>
<li><img src="img/ellipse-17@1x.png"><span>4<br>Hrs</span></li>
<li><img src="img/ellipse-15@1x.png"><span>2<br>Mins</span></li>
<li><img src="img/ellipse-14@1x.png"><span>10<br>Sec</span></li>
</ul>
</div>
</div>


</div>
</div>

<div class="col-md-6">
<div class="add_member_bx">

<h3 class="member_add">Add Member</h3> 
<div class="row">

<div class="col-md-6 form_col">
<form class="form_margin">
<div class="input-wrapper">
  <input type="text" id="id" value="1254666" required>
  <label for="id">ITS ID</label>
</div>

<div class="input-wrapper mt-3">
  <input type="text" id="pass" value="1254666" required>
  <label for="pass">Password</label>
</div>

<div class="input-wrapper mt-3">
  <input type="text" class="add_input" id="addgroup" value="Add To Group" required>
</div>
</form>
</div>



<div class="col-md-6">
<div>
<p>To add members to your group, kindly enter ITS ID & Password and click on <span>"Add To Group"</span> Button.</p>
<span class="orspan">OR</span>

<p class="Register_Member"><a href="#">Register Member(s) from your Member(s) List.</a></p>
</div>
</div>

</div>
</div>
</div>


<div class="col-md-12 tbl_col">
    <div class="table_add_member_bx">
<div class="list_group">
<h4>List of Group Member(s)<span class="span_btn5">5</span></h4>
</div>

<div>
<table class="table table_design">
<thead>
<tr>
<th>Sr.</th>
<th>ITS ID</th>
<th>Full Name</th>
<th>Registration Status</th>
<th>Raza Status</th>
<th>WaraQat-ul Tarkhis</th>
<th><img src="img/icon-material-error-outline-1@1x.png" width="14px"> </th>
</tr>
</thead>
<tbody class="t-body">
<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img">Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td>Arrival/Departure details NOT entered</td>
<td>Pending</td>
<td>NOT Renewed</td>
<td>0</td>
<td><span>Cancel Registration</span></td>
</tr>

<tr>
<td>1.</td>
<td>30462903</td>
<td><img src="img/image-26-12@1x.png" class="shaikh_img"> Mulla Quraish Bhai Shaikh Abizer Bhai Tyebji</td>
<td>Arrival/Departure details NOT entered</td>
<td>Pending</td>
<td>NOT Renewed</td>
<td>0</td>
<td><span>Cancel Registration</span></td>
</tr>

</tbody>
</table>
</div>

</div>
</div>


</div>
</div>
</section>



</body>


 <script src="js/js/jquery.slim.min.js"></script>
  <script src="js/js/popper.min.js"></script>
  <script src="js/js/bootstrap.bundle.min.js"></script>

</html>
