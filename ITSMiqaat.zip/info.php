<?php include('include/header.php'); ?>


<section class="mt-5">
<div class="container">
<div class="row">
    
<div class="col-md-12">
<h5 class="title-icons"><img src="img/leftarrow.png"> Important information(s) regarding Roundat Tahera Daakhi Sharaf 1444H,Mumbai</h5>
</div>

<div class="col-md-12 tbl_col">
<div class="table_add_member_bx">
<div class="list_group mb-3">
<h4><b>General Instructions</b></h4>
</div>

<p>You will receive an email when eligible for a Daakhli pass for Self allocation.</p>

<p>Registration does not guarantee a pass. Aqa Moula tus ni khushi muwafiq sagla mumineen ne daakhli Naseeb thay em hamari Koshish rehse.Your cooperation will be appreciated.</p>

<p>Mumineen who have a valid daakhli pass should ensure every child / Infant in their family has a valid ITS card for entry. If child / Infant cards are not made, they should be made immediately with their respective Aamil saheb & Jamaat offices. Child / Infant entry to Raudat tahera without ITS card will result in undue waiting time & inconvenience.</p>

<p><b>Mumineen are strictly informed not to come to Raudat tahera for Daakhli without a valid pass.</b></p>

</div>
</div>

<div class="col-md-12 tbl_col">
<div class="table_add_member_bx">
<div class="list_group mb-3">
<h4><b>ITS Lost Card Offlice</b></h4>
</div>

<p class="m-0">Support Help Desk </p>
<p class="m-0"><b>Add.: </b> Idaratut Ta'reef al Shakhsi (ITS), <br>Dawat -e- Hadiyah,<br> Amatullah Manzil, Ground Floor, <br>65, Bazargate Street, <br>Fort Mumbai - 400001 India. </p>
<p class="m-0">Tele.: + 91 22 68075353</p>


</div>
</div>

</div>
</div>
</section>

<?php include('include/footer.php'); ?>
