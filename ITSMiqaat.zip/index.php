<?php include('include/header.php'); ?>

<section class="mt-5">  
<div class="container">
<div class="row">

<div class="col-md-12">
<h3 class="miqaat_list">LIST OF MIQAAT(S)</h3>
</div>

<div class="col-md-12">
<div class="row">
<div class="col-md-8">
<div class="miqaat_li_bx1">
<h4>Wada Majlis 1444H, Kuwait <span class="new_span_btn">NEW</span></h4>
<p class="miqaat_p">Friday, 20th Safar-ul-Muzaffar 1444H • Friday, 16th September 2022</p>
<p>Registration ends <span>27 Sept 2022</span></p>
<p><a href="#">Register</a>
<a href="info.php">Information</a></p>

</div>

<div class="miqaat_li_bx1 mt-2">
<h4>Test 10 days 1444H., Testing</h4>
<p class="miqaat_p">Friday, 20th Safar-ul-Muzaffar 1444H • Friday, 16th September 2022</p>
<p>Registration ends <span>27 Sept 2022</span></p>
<p>
<a class="pass_status_btn" href="#">Pass status</a>
<a href="#">check status</a>
<a href="edit.php">Add/Edit</a></p>

</div>


<div class="miqaat_li_bx1 mt-2">
<h4>Raudat Tahera Daakhli Sharaf 1444H., Mumbai</h4>
<p class="miqaat_p">Friday, 20th Safar-ul-Muzaffar 1444H • Friday, 16th September 2022</p>
<p>Registration ends <span>27 Sept 2022</span></p>
<p>
<a class="pass_status_btn" href="#">Pass status</a>
<a href="#">check status</a>
<a href="edit.php">Add/Edit</a></p>

</div>


<div class="miqaat_li_bx1 mt-2">
<h4>Test 10 days 1444H., Testing</h4>
<p class="miqaat_p">Friday, 20th Safar-ul-Muzaffar 1444H • Friday, 16th September 2022</p>
<p>Registration ends <span>27 Sept 2022</span></p>
<p>
<a class="pass_status_btn" href="#">Pass status</a>
<a href="#">check status</a>
<a href="edit.php">Add/Edit</a></p>

</div>


<div class="miqaat_li_bx1 mt-2">
<h4>Raudat Tahera Daakhli Sharaf 1444H., Mumbai</h4>
<p class="miqaat_p">Friday, 20th Safar-ul-Muzaffar 1444H • Friday, 16th September 2022</p>
<p>Registration ends <span>27 Sept 2022</span></p>
<p>
<a class="pass_status_btn" href="#">Pass status</a>
<a href="#">check status</a>
<a href="edit.php">Add/Edit</a></p>

</div>


</div>

<div class="col-md-4 marginlistokbox">
<div class="side_box">
<h3><span>Help</span ></h3>
<ul>
<li>To update your contact details kindly click on the <b>Update Contact Details</b> button under <b>Steps</b> section on <b>Add/Edit page.</b></li>

<li>
To update your arrival details kindly click on the <b>Update Arrival Details </b>button under <b>Steps </b>section on <b>Add/Edit page.</b> </li>

<li>
To araz for pass in the main masjid or rahat block, adding child etc kindly click on the <b>Update Waaz Details</b> button under <b>Steps</b> section on <b>Add/Edit page.</b></li>


<li>
To update Accompanied by child kindly click on the <b>Update Waaz Details</b> button under <b>Steps</b> section on <b>Add/Edit page.</b></li>

</ul>
</div>

</div>

</div>
</div>


</div>
</div>

</div>
</div>
</section>

<?php include('include/footer.php'); ?>